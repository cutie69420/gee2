
import pandas as pd, numpy as np, math
from global_model_v5 import GlobalFootballModel

def walk_forward_sample(path="data/international_results.csv", test_matches=80, refit_every=10):
    d=pd.read_csv(path);d["date"]=pd.to_datetime(d["date"]);d=d.sort_values("date")
    test=d.tail(min(test_matches,len(d)//5 if len(d)>=100 else 0))
    if test.empty:return {"n":0}
    losses=[];briers=[]; model=None; last_block=-1
    for j,(_,row) in enumerate(test.iterrows()):
        if model is None or j//refit_every!=last_block:
            cutoff=row["date"]
            model=GlobalFootballModel(history_years=5.0,half_life_years=1.35).load(path).fit(cutoff)
            last_block=j//refit_every
        try:p=model.predict(row.home_team,row.away_team,bool(row.neutral))["probabilities"]
        except Exception:continue
        probs=np.array([p["home_win"],p["draw"],p["away_win"]],float)
        k=0 if row.home_score>row.away_score else 1 if row.home_score==row.away_score else 2
        y=np.zeros(3);y[k]=1
        losses.append(-math.log(max(probs[k],1e-12)));briers.append(float(((probs-y)**2).sum()))
    return {"n":len(losses),"log_loss":float(np.mean(losses)) if losses else None,
            "brier":float(np.mean(briers)) if briers else None}

from __future__ import annotations
import math, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import poisson

from data_fetch import ensure_results
from analytics_v11 import competition_weight

def _dc_tau(x,y,lh,la,rho):
    if x==0 and y==0: return 1-lh*la*rho
    if x==0 and y==1: return 1+lh*rho
    if x==1 and y==0: return 1+la*rho
    if x==1 and y==1: return 1-rho
    return 1.0

class GlobalFootballModel:
    def __init__(self, history_years=5.0, half_life_years=1.35, friendly_weight=.70):
        self.history_years=history_years
        self.half_life_years=half_life_years
        self.friendly_weight=friendly_weight
        self.teams=[]
        self.params=None
        self.rho=0.0
        self.as_of=None
        self.matches=None

    def load(self, csv_path=None, refresh=False):
        p=ensure_results(csv_path or "data/international_results.csv", refresh=refresh)
        d=pd.read_csv(p)
        d["date"]=pd.to_datetime(d["date"])
        d["neutral"]=d["neutral"].astype(str).str.upper().eq("TRUE") | (d["neutral"]==True)
        self.matches=d
        return self

    def fit(self, as_of=None):
        if self.matches is None: self.load()
        d=self.matches.copy()
        self.as_of=pd.Timestamp(as_of) if as_of else d["date"].max()+pd.Timedelta(days=1)
        lo=self.as_of-pd.Timedelta(days=int(365.25*self.history_years))
        d=d[(d.date<self.as_of)&(d.date>=lo)].copy()
        self.teams=sorted(set(d.home_team)|set(d.away_team))
        idx={t:i for i,t in enumerate(self.teams)}
        n=len(self.teams)
        age=(self.as_of-d.date).dt.days.values
        w=.5**(age/(365.25*self.half_life_years))
        w*=d.tournament.map(competition_weight).astype(float).values
        hi=d.home_team.map(idx).values; ai=d.away_team.map(idx).values
        hg=d.home_score.values.astype(int); ag=d.away_score.values.astype(int)
        neutral=d.neutral.values.astype(bool)

        def unpack(z):
            att=z[:n]; de=z[n:2*n]; home=z[-2]; rho=np.tanh(z[-1])*.18
            att=att-att.mean(); de=de-de.mean()
            return att,de,home,rho

        def obj(z):
            att,de,home,rho=unpack(z)
            lh=np.exp(att[hi]-de[ai]+home*(~neutral))
            la=np.exp(att[ai]-de[hi])
            ll=poisson.logpmf(hg,lh)+poisson.logpmf(ag,la)
            taus=np.array([max(_dc_tau(int(x),int(y),a,b,rho),1e-8) for x,y,a,b in zip(hg,ag,lh,la)])
            ll+=np.log(taus)
            reg=.025*(np.sum(att**2)+np.sum(de**2))
            return -np.sum(w*ll)+reg
        z0=np.zeros(2*n+2); z0[-2]=.18
        res=minimize(obj,z0,method="L-BFGS-B",options={"maxiter":350})
        self.params=unpack(res.x)
        self.rho=self.params[3]
        self._idx=idx
        self._train=d
        return self

    def ratings(self, team):
        att,de,home,rho=self.params
        i=self._idx[team]
        # fixed conservative display mapping, centered at 50
        A=float(np.clip(50+12*att[i],5,90))
        D=float(np.clip(50-12*de[i],5,90))
        O=float(np.clip(.52*A+.48*D,5,90))
        return {"ATT":round(A,1),"DEF":round(D,1),"OVR":round(O,1)}

    def predict(self, home_team, away_team, neutral=False, lineup_home=0.0, lineup_away=0.0, max_goals=8):
        if self.params is None: raise RuntimeError("fit() first")
        att,de,home,rho=self.params
        h=self._idx[home_team]; a=self._idx[away_team]
        # lineup modifiers deliberately tiny: input is capped log-goal adjustment
        lh=float(np.exp(att[h]-de[a]+home*(not neutral)+np.clip(lineup_home,-.08,.08)))
        la=float(np.exp(att[a]-de[h]+np.clip(lineup_away,-.08,.08)))
        grid=np.zeros((max_goals+1,max_goals+1))
        for x in range(max_goals+1):
            for y in range(max_goals+1):
                grid[x,y]=poisson.pmf(x,lh)*poisson.pmf(y,la)*_dc_tau(x,y,lh,la,rho)
        grid/=grid.sum()
        hw=float(np.tril(grid,-1).sum()); draw=float(np.trace(grid)); aw=float(np.triu(grid,1).sum())
        # rows are home goals, cols away goals: tril => home goals > away goals
        btts=float(grid[1:,1:].sum())
        totals={}
        for line in [0.5,1.5,2.5,3.5,4.5,5.5]:
            over=sum(grid[x,y] for x in range(max_goals+1) for y in range(max_goals+1) if x+y>line)
            totals[f"over_{line}"]=float(over); totals[f"under_{line}"]=float(1-over)
        best=np.unravel_index(np.argmax(grid),grid.shape)
        return {
          "home_team":home_team,"away_team":away_team,"neutral":neutral,
          "ratings":{home_team:self.ratings(home_team),away_team:self.ratings(away_team)},
          "expected_goals":{home_team:round(lh,3),away_team:round(la,3)},
          "probabilities":{"home_win":round(hw,4),"draw":round(draw,4),"away_win":round(aw,4),
                           "btts_yes":round(btts,4),**{k:round(v,4) for k,v in totals.items()}},
          "most_likely_score":{"home":int(best[0]),"away":int(best[1]),"probability":round(float(grid[best]),4)},
          "score_grid": [[round(float(v),6) for v in row] for row in grid.tolist()],
          "dixon_coles_rho":round(float(rho),4),
          "as_of":str(self.as_of.date())
        }

    def recent_matches(self, team, n=10):
        d=self.matches[(self.matches.home_team==team)|(self.matches.away_team==team)].sort_values("date").tail(n)
        out=[]
        for _,r in d.iterrows():
            home=(r.home_team==team)
            gf=int(r.home_score if home else r.away_score); ga=int(r.away_score if home else r.home_score)
            out.append({"date":str(r.date.date()),"opponent":r.away_team if home else r.home_team,
                        "venue":"N" if bool(r.neutral) else ("H" if home else "A"),
                        "gf":gf,"ga":ga,"result":"W" if gf>ga else "D" if gf==ga else "L",
                        "tournament":r.tournament})
        return out

    def save_prediction(self,pred,path="prediction_ledger.jsonl"):
        with open(path,"a",encoding="utf8") as f: f.write(json.dumps(pred)+"\n")

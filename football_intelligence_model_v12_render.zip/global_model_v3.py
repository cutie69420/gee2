from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Dict, Optional
import numpy as np
import pandas as pd
from uefa_model_v2 import Config as V2Config, DataPipeline, UEFAForecastModel

@dataclass
class GlobalConfig(V2Config):
    start_date: str = '2021-01-01'      # modern 5-year window by default
    history_years: float = 5.0
    half_life_days: float = 540.0       # recent matches matter more inside window
    rating_center: float = 50.0
    rating_points_per_log_goal: float = 18.0
    rating_min: float = 10.0
    rating_max: float = 90.0
    reliability_matches: float = 18.0   # shrink sparse teams toward 50
    lineup_attack_cap: float = 8.0
    lineup_defense_cap: float = 8.0
    lineup_lambda_cap: float = 0.30     # cap lineup effect on log scoring rate

@dataclass
class PlayerAvailability:
    name: str
    status: str = 'available'  # available, doubtful, out, suspended, not_selected
    position: str = 'UNK'
    expected_minutes_share: float = 1.0
    attack_impact: float = 0.0   # rating points at full expected minutes
    defense_impact: float = 0.0
    confidence: float = 1.0
    source: str = ''

@dataclass
class MatchContext:
    neutral: bool = False
    home_players: list[PlayerAvailability] = field(default_factory=list)
    away_players: list[PlayerAvailability] = field(default_factory=list)

class GlobalInternationalModel(UEFAForecastModel):
    """Worldwide men's international model with stable ratings + match-day availability.

    Historical ratings reflect only the configured modern window. Player availability is
    deliberately temporary: it changes the fixture forecast, not the country's long-term rating.
    """
    def __init__(self, cfg: GlobalConfig = GlobalConfig()):
        super().__init__(cfg)
        self.cfg: GlobalConfig = cfg
        self.team_match_counts: Dict[str, int] = {}

    def fit(self, df: pd.DataFrame, as_of=None):
        d=df.copy()
        ref=pd.Timestamp(as_of) if as_of is not None else pd.Timestamp(d.date.max()) + pd.Timedelta(days=1)
        cutoff=ref-pd.Timedelta(days=int(round(self.cfg.history_years*365.25)))
        d=d[(d.date < ref) & (d.date >= cutoff)].copy()
        if len(d)<50: raise ValueError('Not enough matches in modern history window')
        super().fit(d, as_of=None)
        self.history_start=cutoff
        self.history_end=ref
        self.team_match_counts=pd.concat([d.home_team,d.away_team]).value_counts().to_dict()
        self._build_stable_ratings()
        self.fit_info.update({'scope':'global senior internationals','history_start':str(cutoff.date()),
                              'history_end':str((ref-pd.Timedelta(days=1)).date()),
                              'history_years':self.cfg.history_years})
        return self

    def _stable_score(self, raw: float, matches: int) -> float:
        # Raw attack/defense parameters are log-goal effects. Translate them onto a fixed
        # global 50-centered scale, then reliability-shrink small samples toward 50.
        evidence=matches/(matches+self.cfg.reliability_matches)
        score=self.cfg.rating_center + self.cfg.rating_points_per_log_goal*raw*evidence
        return float(np.clip(score,self.cfg.rating_min,self.cfg.rating_max))

    def _build_stable_ratings(self):
        att,de,*_=self._unpack(self.params)
        self.ratings={}
        for t,i in self.tidx.items():
            n=int(self.team_match_counts.get(t,0))
            A=self._stable_score(float(att[i]),n); D=self._stable_score(float(de[i]),n)
            # geometric mean penalizes one-dimensional teams more naturally than a plain mean
            O=math.sqrt(A*D)
            self.ratings[t]={'attack_raw':float(att[i]),'defense_raw':float(de[i]),
                             'attack':round(A,1),'defense':round(D,1),'overall':round(O,1),
                             'matches_5y':n,'rating_reliability':round(n/(n+self.cfg.reliability_matches),3)}

    @staticmethod
    def _absence_fraction(p: PlayerAvailability) -> float:
        s=p.status.lower().strip()
        if s in {'out','suspended','not_selected'}: unavailable=1.0
        elif s=='doubtful': unavailable=0.5
        else: unavailable=0.0
        return unavailable*np.clip(p.expected_minutes_share,0,1)*np.clip(p.confidence,0,1)

    def lineup_adjustment(self, players: list[PlayerAvailability]):
        a=d=0.0; reasons=[]
        for p in players:
            f=self._absence_fraction(p)
            if f<=0: continue
            da=-p.attack_impact*f; dd=-p.defense_impact*f
            a+=da; d+=dd
            reasons.append({'player':p.name,'status':p.status,'position':p.position,
                            'attack_delta':round(float(da),2),'defense_delta':round(float(dd),2),
                            'confidence':p.confidence,'source':p.source})
        a=float(np.clip(a,-self.cfg.lineup_attack_cap,self.cfg.lineup_attack_cap))
        d=float(np.clip(d,-self.cfg.lineup_defense_cap,self.cfg.lineup_defense_cap))
        return a,d,reasons

    def predict_match(self, home: str, away: str, context: Optional[MatchContext]=None, features=None):
        context=context or MatchContext()
        if home not in self.tidx or away not in self.tidx:
            missing=[t for t in (home,away) if t not in self.tidx]
            raise KeyError(f'No modern-history rating for: {missing}. Add prior/shrinkage support before forecasting.')
        ha,hd,hr=self.lineup_adjustment(context.home_players)
        aa,ad,ar=self.lineup_adjustment(context.away_players)
        lh,la=super().lambdas(home,away,context.neutral,features)
        # Rating-point deltas are converted to bounded log-rate changes. Missing attackers lower
        # own lambda; missing defenders raise opponent lambda. Both sides can act simultaneously.
        scale=max(self.cfg.rating_points_per_log_goal,1e-6)
        log_h=np.clip((ha-ad)/scale,-self.cfg.lineup_lambda_cap,self.cfg.lineup_lambda_cap)
        log_a=np.clip((aa-hd)/scale,-self.cfg.lineup_lambda_cap,self.cfg.lineup_lambda_cap)
        lh*=math.exp(float(log_h)); la*=math.exp(float(log_a))
        g=np.arange(self.cfg.max_goals+1); from scipy.stats import poisson
        M=np.outer(poisson.pmf(g,lh),poisson.pmf(g,la))
        for x in (0,1):
            for y in (0,1): M[x,y]*=self._tau(x,y,lh,la,self.rho)
        M/=M.sum(); total=np.add.outer(g,g); i,j=np.unravel_index(np.argmax(M),M.shape)
        def match_rating(base,delta): return round(float(np.clip(base+delta,self.cfg.rating_min,self.cfg.rating_max)),1)
        confidence=min(self.ratings[home]['rating_reliability'],self.ratings[away]['rating_reliability'])
        if any(p.status.lower()=='doubtful' for p in context.home_players+context.away_players): confidence*=0.90
        out={'home':home,'away':away,'historical_home':self.ratings[home],'historical_away':self.ratings[away],
             'matchday_home':{'attack':match_rating(self.ratings[home]['attack'],ha),'defense':match_rating(self.ratings[home]['defense'],hd)},
             'matchday_away':{'attack':match_rating(self.ratings[away]['attack'],aa),'defense':match_rating(self.ratings[away]['defense'],ad)},
             'availability':{'home':hr,'away':ar},'lambda_home':float(lh),'lambda_away':float(la),
             'home_win':float(np.tril(M,-1).sum()),'draw':float(np.trace(M)),'away_win':float(np.triu(M,1).sum()),
             'btts_yes':float(M[1:,1:].sum()),'most_likely_score':f'{i}-{j}','score_probability':float(M[i,j]),
             'data_confidence':round(float(confidence),3),'score_matrix':M}
        out.update({f'over_{x:.1f}':float(M[total>x].sum()) for x in [.5,1.5,2.5,3.5,4.5,5.5]})
        return out

from pathlib import Path
import pandas as pd, numpy as np, json, os, urllib.request

FIELDS=["date","home_team","away_team","xg_home","xg_away","xgot_home","xgot_away",
        "shots_home","shots_away","sot_home","sot_away","possession_home","possession_away",
        "big_chances_home","big_chances_away","source","fixture_id"]

def load_enrichment(path="data/advanced_stats.csv"):
    p=Path(path)
    if not p.exists():
        return pd.DataFrame(columns=FIELDS)
    d=pd.read_csv(p)
    for c in FIELDS:
        if c not in d: d[c]=np.nan
    return d[FIELDS]

def coverage(df):
    if df.empty:return {"matches":0}
    return {"matches":len(df), **{c:int(df[c].notna().sum()) for c in FIELDS if c not in ("date","home_team","away_team","source","fixture_id")}}

def template(path="data/advanced_stats.csv"):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    if not p.exists(): pd.DataFrame(columns=FIELDS).to_csv(p,index=False)
    return p

if __name__=="__main__":
    print(template())

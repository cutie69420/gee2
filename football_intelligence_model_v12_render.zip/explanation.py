def explain_prediction(pred, recent_home=None, recent_away=None, lineup_note=None, advanced_note=None):
    h,a=pred["home_team"],pred["away_team"]; p=pred["probabilities"]; r=pred["ratings"]; eg=pred["expected_goals"]
    ph,pd,pa=p["home_win"],p["draw"],p["away_win"]
    favorite=h if ph>=max(pd,pa) else a if pa>=max(ph,pd) else None
    parts=[]
    gap=r[h]["OVR"]-r[a]["OVR"]
    if abs(gap)>=8:
        stronger=h if gap>0 else a
        parts.append(f"{stronger} has the stronger underlying team rating, with a meaningful overall-strength advantage.")
    elif abs(gap)>=3:
        stronger=h if gap>0 else a
        parts.append(f"{stronger} has a modest underlying rating edge, so the matchup is not treated as one-sided.")
    else:
        parts.append("The teams are relatively close in underlying strength, which keeps the result probabilities compressed.")
    xgap=eg[h]-eg[a]
    if abs(xgap)>=.35:
        side=h if xgap>0 else a
        parts.append(f"The attack-versus-defense matchup gives {side} the higher scoring rate ({eg[h]:.2f}–{eg[a]:.2f} expected goals).")
    else:
        parts.append(f"The projected scoring rates are close ({eg[h]:.2f}–{eg[a]:.2f}), leaving substantial draw/upset uncertainty.")
    if not pred.get("neutral",False):
        parts.append(f"Venue is included: {h} receives the model's learned home-field effect.")
    if lineup_note: parts.append(lineup_note)
    if advanced_note: parts.append(advanced_note)
    return " ".join(parts[:4])

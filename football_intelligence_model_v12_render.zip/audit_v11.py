
import pandas as pd
def audit(path="data/international_results.csv"):
    d=pd.read_csv(path); issues=[]
    req=["date","home_team","away_team","home_score","away_score","tournament","neutral"]
    miss=[c for c in req if c not in d.columns]
    if miss:issues.append("Missing columns: "+",".join(miss))
    if not miss:
        if d[req].isna().any().any():issues.append("Nulls exist in required core fields")
        if (d.home_team==d.away_team).any():issues.append("Self-match rows detected")
        if d.duplicated(["date","home_team","away_team"]).any():issues.append("Duplicate date/team fixtures detected")
        if (d[["home_score","away_score"]]<0).any().any():issues.append("Negative score detected")
    return {"rows":len(d),"issues":issues,"status":"PASS" if not issues else "REVIEW"}
if __name__=="__main__":
    import json;print(json.dumps(audit(),indent=2))

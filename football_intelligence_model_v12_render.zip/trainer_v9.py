from pathlib import Path
import pandas as pd, json
from global_model_v5 import GlobalFootballModel
from database import record_run

MODEL_VERSION="v12-render"

def train(data=None,as_of=None):
    from paths_v12 import RESULTS_CSV
    data = str(data or RESULTS_CSV)
    m=GlobalFootballModel(history_years=5.0,half_life_years=1.35).load(data).fit(as_of)
    record_run(MODEL_VERSION,str(m.as_of.date()),len(m._train),len(m.teams),m.history_years,m.half_life_years,
               "Weighted rolling Poisson + Dixon-Coles refit")
    return m

def refresh_and_train():
    from data_fetch import ensure_results
    from paths_v12 import RESULTS_CSV
    ensure_results(str(RESULTS_CSV),refresh=True)
    return train()

# v12 Render deployment

This build turns v11 into a deployable API while preserving the football model.

## What changed
- Added FastAPI endpoints: `/health`, `/teams`, `POST /predict`, `POST /admin/retrain`.
- Added `render.yaml`.
- Added persistent storage configuration through `FOOTBALL_DATA_DIR`.
- Integrated the v11 competition-weight function into the actual model fit.
- Kept lineup effects bounded to ±0.08 log-goals.
- Keeps missing advanced/lineup data missing instead of inventing values.
- Removed the bundled local SQLite database from the deployment package.

## Render
1. Put these files in the root of your GitHub repository.
2. In Render, create a new Blueprint and select that repository.
3. Render reads `render.yaml`.
4. Approve the web service and persistent disk.
5. After deployment, open `/docs` on the service URL to test predictions.

The disk is intentionally attached to the same single web service that owns SQLite.
Do not create a separate Render cron job that tries to write this SQLite database.

## Retraining
`POST /admin/retrain` refreshes observed international results and refits the model.
It requires:
`Authorization: Bearer <FOOTBALL_ADMIN_KEY>`

Keep that key in Render environment variables only. Never commit it.

## ChatGPT integration
The hosted `/predict` endpoint is suitable for a future custom plugin/connector.
Hosting the endpoint alone does not automatically give every ChatGPT conversation permission to call it.

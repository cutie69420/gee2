
from data_fetch import ensure_results
from audit_v11 import audit
from learning_v11 import auto_settle
from validation_v11 import walk_forward_sample
from trainer_v9 import train
def main():
    ensure_results("data/international_results.csv",refresh=True)
    a=audit()
    if a["status"]!="PASS": raise RuntimeError("Data audit failed: "+str(a["issues"]))
    settled=auto_settle()
    val=walk_forward_sample(test_matches=80,refit_every=10)
    m=train()
    print({"audit":a,"settled":settled,"validation":val,"trained_through":str(m.as_of.date())})
if __name__=="__main__":main()

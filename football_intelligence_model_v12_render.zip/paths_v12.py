from pathlib import Path
import os

DATA_DIR = Path(os.getenv("FOOTBALL_DATA_DIR", "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_CSV = DATA_DIR / "international_results.csv"
DB_PATH = DATA_DIR / "football_model.db"

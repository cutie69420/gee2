import streamlit as st, pandas as pd, numpy as np
from pathlib import Path
from difflib import get_close_matches
from trainer_v9 import train,refresh_and_train,MODEL_VERSION
from database import save_prediction,settle_prediction,table,connect
from explanation import explain_prediction
from source_registry import SOURCES
from analytics_v11 import team_recent_signal,uncertainty,data_confidence,explanation
from learning_v11 import auto_settle,calibration_bins
from validation_v11 import walk_forward_sample

st.set_page_config(page_title="Football Intelligence Model",page_icon="⚽",layout="wide")
DATA="data/international_results.csv"; connect()
st.title("⚽ Football Intelligence Model v11")
st.caption("Persistent, retrainable international match forecasting system")
st.info("You are in the live Python app. If you ever see {{...}} or {% ... %}, you opened an old HTML file instead of this app.")

def need_data():
    if Path(DATA).exists(): return True
    st.error("Core match database is not installed.")
    if st.button("Download data and train model",type="primary"):
        try:
            with st.spinner("Downloading and training…"): refresh_and_train()
            st.cache_resource.clear();st.rerun()
        except Exception as e:st.error(str(e))
    return False

@st.cache_resource(show_spinner="Training current model…")
def get_model(mtime): return train(DATA)

def resolve(q,teams):
    q=(q or "").strip()
    exact={t.lower():t for t in teams}
    aliases={"usa":"United States","us":"United States","cote d'ivoire":"Ivory Coast","ivory coast":"Ivory Coast"}
    if q.lower() in aliases and aliases[q.lower()] in teams:return aliases[q.lower()]
    if q.lower() in exact:return exact[q.lower()]
    p=[t for t in teams if t.lower().startswith(q.lower())]
    if len(p)==1:return p[0]
    c=get_close_matches(q,teams,n=4,cutoff=.55)
    raise ValueError("Team not recognized uniquely."+(" Try: "+", ".join(c) if c else ""))

if need_data():
    m=get_model(Path(DATA).stat().st_mtime)
    tab1,tab2,tab3,tab4=st.tabs(["Predict","Prediction history","Data","Model health"])
    with tab1:
        with st.form("predict_form"):
            a,b=st.columns(2)
            team1=a.text_input("Team 1",placeholder="Germany")
            team2=b.text_input("Team 2",placeholder="Serbia")
            venue=st.radio("Venue",["Team 1 home","Neutral","Team 2 home"],horizontal=True)
            match_date=st.date_input("Match date (optional)")
            go=st.form_submit_button("Generate prediction",type="primary",use_container_width=True)
        if go:
            try:
                t1=resolve(team1,m.teams);t2=resolve(team2,m.teams)
                if t1==t2:raise ValueError("Choose different teams")
                pred=m.predict(t2,t1,False) if venue=="Team 2 home" else m.predict(t1,t2,venue=="Neutral")
                save_prediction(pred,str(match_date),venue,MODEL_VERSION)
                p=pred["probabilities"]; choices=[(pred["home_team"],p["home_win"]),("Draw",p["draw"]),(pred["away_team"],p["away_win"])]
                pick,prob=max(choices,key=lambda z:z[1])
                st.success(f"Highest-probability outcome: {pick} ({prob*100:.1f}%)")
                c1,c2,c3=st.columns(3);c1.metric(pred["home_team"],f'{p["home_win"]*100:.1f}%');c2.metric("Draw",f'{p["draw"]*100:.1f}%');c3.metric(pred["away_team"],f'{p["away_win"]*100:.1f}%')
                st.subheader(f'Most likely score: {pred["home_team"]} {pred["most_likely_score"]["home"]}–{pred["most_likely_score"]["away"]} {pred["away_team"]}')
                st.write("Expected goals:",pred["expected_goals"]," | BTTS:",f'{p["btts_yes"]*100:.1f}%'," | Over 2.5:",f'{p["over_2.5"]*100:.1f}%')
                st.markdown("### Why the model predicts this")
                rh=team_recent_signal(m.matches,pred["home_team"],m.as_of)
                ra=team_recent_signal(m.matches,pred["away_team"],m.as_of)
                conf=data_confidence(m.matches,pred["home_team"],pred["away_team"],0,0,m.as_of)
                st.write(explanation(pred,rh,ra,conf))
                u1,u2=uncertainty(m.matches,pred["home_team"],m.as_of),uncertainty(m.matches,pred["away_team"],m.as_of)
                st.caption(f'Evidence uncertainty — {pred["home_team"]}: ±{u1["rating_uncertainty"]} rating pts; {pred["away_team"]}: ±{u2["rating_uncertainty"]} rating pts. Data confidence: {conf}/100.')

                r1,r2=st.columns(2)
                r1.json(pred["ratings"][pred["home_team"]]);r2.json(pred["ratings"][pred["away_team"]])
                grid=np.array(pred["score_grid"])[:7,:7]*100
                st.dataframe(pd.DataFrame(grid,index=range(7),columns=range(7)).round(2),use_container_width=True)
            except Exception as e:st.error(str(e))
    with tab2:
        d=table("predictions")
        st.dataframe(d.drop(columns=["payload"],errors="ignore"),use_container_width=True,hide_index=True)
        unsettled=d[d.settled==0] if not d.empty else d
        if not unsettled.empty:
            st.markdown("#### Settle a completed prediction")
            pid=st.selectbox("Prediction ID",unsettled.id.tolist())
            x,y=st.columns(2);ah=x.number_input("Actual home goals",0,30,0);aa=y.number_input("Actual away goals",0,30,0)
            if st.button("Save result + score prediction"):
                settle_prediction(int(pid),int(ah),int(aa));st.rerun()
        if not d.empty: st.download_button("Export predictions CSV",d.to_csv(index=False),"predictions.csv","text/csv")
    with tab3:
        st.write("Core match database:",DATA)
        st.write("Persistent SQLite database:","data/football_model.db")
        st.markdown("#### Credible data-source registry")
        st.dataframe(pd.DataFrame([{"source":k,**v} for k,v in SOURCES.items()]),use_container_width=True,hide_index=True)
        for name in ["advanced_stats","lineup_snapshots","source_observations","model_runs"]:
            with st.expander(name):
                d=table(name);st.dataframe(d,use_container_width=True,hide_index=True)
                st.download_button(f"Export {name}",d.to_csv(index=False),f"{name}.csv","text/csv",key="dl"+name)
        if st.button("Refresh completed-match source + retrain",type="primary"):
            try:
                with st.spinner("Refreshing and retraining…"): refresh_and_train()
                st.cache_resource.clear();st.success("Retrained.");st.rerun()
            except Exception as e:st.error(str(e))
    with tab4:
        d=table("predictions"); settled=d[d.settled==1] if not d.empty else d
        st.metric("Stored predictions",len(d));st.metric("Scored predictions",len(settled))
        if st.button("Auto-settle completed predictions"):
            n=auto_settle(DATA);st.success(f"Settled {n} prediction(s) from observed results.");st.rerun()
        if not settled.empty:
            a,b,c=st.columns(3);a.metric("Mean log loss",f'{settled.log_loss.mean():.3f}');b.metric("Mean Brier",f'{settled.brier.mean():.3f}');c.metric("Mean RPS",f'{settled.rps.mean():.3f}')
        st.dataframe(table("model_runs"),use_container_width=True,hide_index=True)
        st.markdown("#### Probability calibration")
        st.dataframe(calibration_bins(),use_container_width=True,hide_index=True)
        if st.button("Run chronological validation"):
            with st.spinner("Running leakage-safe walk-forward validation…"):
                st.json(walk_forward_sample(DATA,80,10))
        st.caption("Retraining uses observed match data. The model does not train on its own predicted labels.")

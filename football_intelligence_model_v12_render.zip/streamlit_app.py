import streamlit as st
import pandas as pd, numpy as np, os, json
from difflib import get_close_matches
from pathlib import Path
from global_model_v5 import GlobalFootballModel
from advanced_data import load_enrichment, coverage, template

st.set_page_config(page_title="International Football Predictor",page_icon="⚽",layout="wide")
st.title("International Football Predictor")
st.caption("Opponent-adjusted international forecasting · rolling 5-year evidence · recent-match weighting · Poisson + Dixon–Coles")

DATA="data/international_results.csv"
template()

@st.cache_resource(show_spinner="Training model from recent international matches…")
def load_model(data_mtime):
    return GlobalFootballModel(history_years=5.0,half_life_years=1.35).load(DATA).fit()

def ensure_data():
    if Path(DATA).exists(): return True
    st.warning("Historical match data is not installed yet.")
    if st.button("Download historical match database"):
        from data_fetch import ensure_results
        try:
            with st.spinner("Downloading…"): ensure_results(DATA,refresh=True)
            st.cache_resource.clear(); st.rerun()
        except Exception as e: st.error(f"Download failed: {e}")
    return False

def resolve(raw,teams):
    q=(raw or "").strip()
    exact={x.lower():x for x in teams}
    aliases={"usa":"United States","us":"United States","south korea":"South Korea",
             "ivory coast":"Ivory Coast","cote d'ivoire":"Ivory Coast",
             "germany":"Germany","wales":"Wales","norway":"Norway","serbia":"Serbia"}
    if q.lower() in aliases and aliases[q.lower()] in teams:return aliases[q.lower()]
    if q.lower() in exact:return exact[q.lower()]
    pref=[x for x in teams if x.lower().startswith(q.lower())]
    if len(pref)==1:return pref[0]
    close=get_close_matches(q,teams,n=3,cutoff=.58)
    if len(close)==1:return close[0]
    raise ValueError("Team not uniquely recognized. Try: "+(", ".join(close) if close else "the country's full national-team name"))

if ensure_data():
    mtime=Path(DATA).stat().st_mtime
    m=load_model(mtime)
    teams=m.teams

    with st.form("prediction"):
        c1,c2=st.columns(2)
        with c1: home_raw=st.text_input("Team 1",value="Wales",placeholder="Type a country, e.g. Wales")
        with c2: away_raw=st.text_input("Team 2",value="Norway",placeholder="Type a country, e.g. Norway")
        venue=st.radio("Venue",["Team 1 home","Neutral","Team 2 home"],horizontal=True)
        submitted=st.form_submit_button("Generate prediction",type="primary",use_container_width=True)

    if submitted:
        try:
            h=resolve(home_raw,teams); a=resolve(away_raw,teams)
            if h==a: raise ValueError("Choose two different teams.")
            if venue=="Team 2 home":
                pred=m.predict(a,h,False)
            else:
                pred=m.predict(h,a,venue=="Neutral")
            m.save_prediction(pred)
            p=pred["probabilities"]
            vals=[(pred["home_team"],p["home_win"]),("Draw",p["draw"]),(pred["away_team"],p["away_win"])]
            pick,pp=max(vals,key=lambda x:x[1])

            st.subheader("Forecast")
            st.markdown(f"### {pick} — {pp*100:.1f}% highest-outcome probability")
            st.caption("Highest probability is not certainty; forecasts should be judged by calibration, not only whether the top outcome wins.")

            x1,x2,x3=st.columns(3)
            x1.metric(pred["home_team"],f'{p["home_win"]*100:.1f}%')
            x2.metric("Draw",f'{p["draw"]*100:.1f}%')
            x3.metric(pred["away_team"],f'{p["away_win"]*100:.1f}%')
            st.info(f'Most likely score: {pred["home_team"]} {pred["most_likely_score"]["home"]}–{pred["most_likely_score"]["away"]} {pred["away_team"]}  |  Goal rates: {pred["expected_goals"][pred["home_team"]]}–{pred["expected_goals"][pred["away_team"]]}')

            r1,r2=st.columns(2)
            for col,t in [(r1,pred["home_team"]),(r2,pred["away_team"])]:
                rr=pred["ratings"][t]
                with col:
                    st.markdown(f"#### {t}")
                    a1,a2,a3=st.columns(3)
                    a1.metric("ATT",rr["ATT"]);a2.metric("DEF",rr["DEF"]);a3.metric("OVR",rr["OVR"])

            st.subheader("Markets / probability diagnostics")
            d=pd.DataFrame({"Market":["BTTS Yes","Over 1.5","Over 2.5","Over 3.5","Under 2.5"],
                            "Probability":[p["btts_yes"],p["over_1.5"],p["over_2.5"],p["over_3.5"],p["under_2.5"]]})
            d["Probability"]=d["Probability"].map(lambda x:f"{x*100:.1f}%")
            st.dataframe(d,use_container_width=True,hide_index=True)

            st.subheader("Exact-score probability matrix")
            grid=np.array(pred["score_grid"])[:7,:7]*100
            st.dataframe(pd.DataFrame(grid,index=[f"H {i}" for i in range(7)],columns=[f"A {i}" for i in range(7)]).round(2),use_container_width=True)

            st.subheader("Recent form")
            f1,f2=st.columns(2)
            f1.dataframe(pd.DataFrame(m.recent_matches(pred["home_team"],10)),use_container_width=True,hide_index=True)
            f2.dataframe(pd.DataFrame(m.recent_matches(pred["away_team"],10)),use_container_width=True,hide_index=True)
        except Exception as e: st.error(str(e))

    with st.expander("Data & model coverage"):
        adv=load_enrichment()
        st.write("Core results rows:",len(m.matches))
        st.write("Advanced-stat coverage:",coverage(adv))
        st.caption("Missing xG/shots/SOT remain missing. The model never converts unavailable advanced statistics into zeros.")
        if st.button("Refresh core match results"):
            from data_fetch import ensure_results
            try:
                ensure_results(DATA,refresh=True); st.cache_resource.clear(); st.rerun()
            except Exception as e: st.error(str(e))

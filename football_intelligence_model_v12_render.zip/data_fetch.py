from pathlib import Path
import urllib.request

RESULTS_URL = "https://raw.githubusercontent.com/martj42/international_results/master/results.csv"

def ensure_results(path="data/international_results.csv", refresh=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not refresh:
        return path
    req = urllib.request.Request(RESULTS_URL, headers={"User-Agent":"global-football-model/5.0"})
    with urllib.request.urlopen(req, timeout=30) as r, open(path, "wb") as f:
        f.write(r.read())
    return path

if __name__ == "__main__":
    p=ensure_results(refresh=True)
    print(p)

import os,json,urllib.parse,urllib.request
BASE="https://api.sportmonks.com/v3/football"
INCLUDES="participants;scores;events;statistics;lineups.player;formations;sidelined.player;sidelined.type;xGFixture"

def get_fixture(fixture_id,token=None):
    token=token or os.getenv("SPORTMONKS_TOKEN")
    if not token: raise RuntimeError("SPORTMONKS_TOKEN is required for licensed enrichment.")
    qs=urllib.parse.urlencode({"api_token":token,"include":INCLUDES})
    req=urllib.request.Request(f"{BASE}/fixtures/{fixture_id}?{qs}",headers={"User-Agent":"football-intelligence-v10"})
    with urllib.request.urlopen(req,timeout=30) as r:return json.load(r)

def expected_lineups(fixture_id,token=None):
    token=token or os.getenv("SPORTMONKS_TOKEN")
    if not token: raise RuntimeError("SPORTMONKS_TOKEN is required.")
    qs=urllib.parse.urlencode({"api_token":token,"include":"expectedLineups"})
    with urllib.request.urlopen(f"{BASE}/fixtures/{fixture_id}?{qs}",timeout=30) as r:return json.load(r)

FOOTBALL INTELLIGENCE MODEL V11

Run only:
 Windows -> RUN_ME_WINDOWS.bat
 macOS   -> RUN_ME_MAC.command

Never open an HTML file. This build has no template directory.

Persistent storage:
 data/international_results.csv = observed historical results
 data/football_model.db = predictions, settled outcomes, advanced stats, lineup
 snapshots, provenance and model runs.

V11 safeguards/features:
 - rolling 5-year Poisson + Dixon-Coles model
 - strict date cutoffs for historical training
 - recency weighting
 - competition-weight framework
 - recent-form signal separated from long-term ratings
 - uncertainty/data-confidence display
 - grounded short prediction explanations
 - immutable stored prediction probabilities
 - automatic settlement against subsequently observed results
 - log loss, Brier score, RPS and calibration bins
 - chronological walk-forward validation
 - data integrity audit before automated retraining
 - source provenance tables
 - optional licensed Sportmonks enrichment adapter
 - missing advanced data remains missing; never silently treated as zero

AUTOMATION:
 Run `python auto_retrain_v11.py` from Windows Task Scheduler/cron for unattended
 refresh/retraining. The machine/server must be running and online.

PHONE:
 A ZIP cannot run a Python server on iOS. Deploy the project to a Python web host
 for an always-on URL, or run Streamlit on a computer/server and access that server.

# UEFA International Football Forecast Model

Dynamic time-decayed attack/defence model with Poisson scoring intensities and Dixon-Coles low-score correction.

## Data
Default result source: Mart Jürisoo `international_results` public CC0 dataset. The loader uses all senior internationals from 2018 onward for opponent context, including UEFA Nations League matches. Add verified advanced stats using `--advanced advanced_stats.csv` with columns:
`date,home_team,away_team,home_xg,away_xg,home_shots,away_shots,home_sot,away_sot`.

Advanced statistics are never imputed as if observed. The current baseline model trains from goals/results; `predict(..., features={...})` supports conservative recent xG/SOT form adjustments. A later feature-regression layer can be trained once sufficient verified advanced-stat coverage is available.

## Install / run
```
pip install -r requirements.txt
python uefa_model.py --home France --away Germany
python uefa_model.py --backtest
python uefa_model.py --data data/results.csv --advanced data/advanced_stats.csv --home Spain --away Portugal
```

## Outputs
ATT/DEF/OVR 0-100 display ratings, expected scoring rates, Dixon-Coles rho, exact-score matrix, 1X2 probabilities, BTTS, totals O0.5-O5.5, and most likely exact score.

## Methodological safeguards
Chronological data only; exponential time decay; neutral-site handling; L2 regularization; centered latent strengths; walk-forward evaluation; no future match leakage. Do not interpret 0-100 display ratings as literal probabilities.

## v3: global ratings + match-day player availability
`global_model_v3.py` expands the forecasting layer to all teams present in the senior international results dataset. Historical ATT/DEF/OVR ratings use a rolling five-year window and a fixed 50-centered scale rather than sample-relative logistic percentiles. Sparse teams are shrunk toward 50.

Player injuries, suspensions and non-selection are represented with `PlayerAvailability` and affect only the specific fixture via `MatchContext`; they do not rewrite long-term national-team strength. `attack_impact` and `defense_impact` must be evidence-based inputs from a player-impact process. Do not invent them. `confidence` can down-weight uncertain reports.

Example:
```python
from global_model_v3 import *
ctx = MatchContext(neutral=False, home_players=[
    PlayerAvailability('Example Forward', status='out', position='FW', expected_minutes_share=.85,
                       attack_impact=2.5, confidence=1.0, source='verified squad report')
])
p = model.predict_match('Team A','Team B',ctx)
```


## v4 expectation-aware update system

v4 adds a rolling **2–5 year** evidence model (maximum five years, with the first
two years weighted most strongly). Each match is evaluated against the probability
forecast that existed before kickoff.

Persistent ratings now distinguish:
- expected/confirming performance,
- overperformance/upsets,
- underperformance/disappointments,
- result surprise versus underlying xG/shots/SOT surprise,
- opponent strength,
- rating confidence/uncertainty,
- repeated surprise patterns.

A favorite winning as expected therefore causes little rating movement but increases
confidence. A genuine low-probability upset creates a larger bounded update. If an
upset scoreline conflicts with xG/shots/SOT, the underlying-performance component
reduces the update. Missing advanced statistics are ignored rather than imputed as
observed values.

Player availability remains a small match-day modifier and is not fed into the
persistent historical strength update.

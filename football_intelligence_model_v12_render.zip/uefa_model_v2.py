from __future__ import annotations
import argparse, json, math
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import poisson

RESULTS_URL='https://raw.githubusercontent.com/martj42/international_results/master/results.csv'
ADV_COLS=['home_xg','away_xg','home_shots','away_shots','home_sot','away_sot']
ALIASES={'Türkiye':'Turkey','Czechia':'Czech Republic','Republic of Ireland':'Ireland','Korea Republic':'South Korea'}

@dataclass
class Config:
    start_date: str='2018-01-01'
    half_life_days: float=540.0
    form_half_life_days: float=180.0
    form_matches: int=10
    home_adv: float=0.12
    max_goals: int=10
    l2: float=0.025
    min_advanced_matches: int=120
    feature_clip: float=3.0

class DataPipeline:
    @staticmethod
    def normalize_team(s):
        s=str(s).strip(); return ALIASES.get(s,s)

    @classmethod
    def load_results(cls,path_or_url=RESULTS_URL):
        d=pd.read_csv(path_or_url,parse_dates=['date'])
        d=d.dropna(subset=['home_team','away_team','home_score','away_score']).copy()
        for c in ['home_team','away_team']: d[c]=d[c].map(cls.normalize_team)
        d[['home_score','away_score']]=d[['home_score','away_score']].astype(int)
        if 'neutral' not in d: d['neutral']=False
        d['neutral']=d['neutral'].astype(str).str.lower().map({'true':True,'false':False}).fillna(False).astype(bool)
        return d.sort_values('date').reset_index(drop=True)

    @classmethod
    def load_advanced(cls,paths):
        if not paths: return pd.DataFrame(columns=['date','home_team','away_team']+ADV_COLS+['source'])
        frames=[]
        for p in paths:
            a=pd.read_csv(p,parse_dates=['date']); a['source']=a.get('source',Path(p).stem)
            for c in ['home_team','away_team']: a[c]=a[c].map(cls.normalize_team)
            for c in ADV_COLS:
                if c not in a: a[c]=np.nan
                a[c]=pd.to_numeric(a[c],errors='coerce')
            frames.append(a[['date','home_team','away_team']+ADV_COLS+['source']])
        a=pd.concat(frames,ignore_index=True)
        key=['date','home_team','away_team']
        # median reconciles small provider differences; spread is retained as conflict diagnostic
        agg={c:'median' for c in ADV_COLS}; agg['source']=lambda x:'|'.join(sorted(set(map(str,x))))
        out=a.groupby(key,as_index=False).agg(agg)
        counts=a.groupby(key).size().rename('provider_count').reset_index()
        return out.merge(counts,on=key,how='left')

    @staticmethod
    def merge(results,advanced):
        key=['date','home_team','away_team']; d=results.copy()
        if advanced is None or advanced.empty:
            for c in ADV_COLS: d[c]=np.nan
            d['source']=np.nan; d['provider_count']=0
        else: d=d.merge(advanced,on=key,how='left')
        for c in ADV_COLS:
            if c not in d: d[c]=np.nan
        return d

    @staticmethod
    def coverage(d):
        return pd.DataFrame({'field':ADV_COLS,'observed':[int(d[c].notna().sum()) for c in ADV_COLS],
                             'coverage_pct':[round(100*d[c].notna().mean(),2) for c in ADV_COLS]})

    @staticmethod
    def add_prematch_form(d,window=10):
        """Leakage-safe rolling features: every row uses only earlier matches."""
        d=d.sort_values('date').reset_index(drop=True).copy(); hist={}; rows=[]
        metrics=['xg','shots','sot','goals']
        for _,r in d.iterrows():
            feats={}
            for side,team,opp in [('home',r.home_team,r.away_team),('away',r.away_team,r.home_team)]:
                h=hist.get(team,[])[-window:]
                for m in metrics:
                    vals=[z[m+'_for'] for z in h if pd.notna(z[m+'_for'])]
                    aga=[z[m+'_against'] for z in h if pd.notna(z[m+'_against'])]
                    feats[f'{side}_{m}_for_form']=np.mean(vals) if vals else np.nan
                    feats[f'{side}_{m}_against_form']=np.mean(aga) if aga else np.nan
            rows.append(feats)
            hg=float(r.home_score); ag=float(r.away_score)
            hv={'goals_for':hg,'goals_against':ag,'xg_for':r.home_xg,'xg_against':r.away_xg,
                'shots_for':r.home_shots,'shots_against':r.away_shots,'sot_for':r.home_sot,'sot_against':r.away_sot}
            av={'goals_for':ag,'goals_against':hg,'xg_for':r.away_xg,'xg_against':r.home_xg,
                'shots_for':r.away_shots,'shots_against':r.home_shots,'sot_for':r.away_sot,'sot_against':r.home_sot}
            hist.setdefault(r.home_team,[]).append(hv); hist.setdefault(r.away_team,[]).append(av)
        return pd.concat([d,pd.DataFrame(rows)],axis=1)

class UEFAForecastModel:
    FEATURE_NAMES=['xg_form_diff','shots_form_diff','sot_form_diff']
    def __init__(self,cfg=Config()): self.cfg=cfg; self.params=None; self.teams=[]; self.tidx={}; self.rho=0.; self.ratings={}; self.feature_mean={}; self.feature_std={}; self.use_advanced=False

    def _decay(self,dates,ref):
        age=(ref-dates).dt.days.clip(lower=0).to_numpy(); return np.exp(-math.log(2)*age/self.cfg.half_life_days)
    @staticmethod
    def _tau(x,y,lh,la,rho):
        if x==0 and y==0:return 1-lh*la*rho
        if x==0 and y==1:return 1+lh*rho
        if x==1 and y==0:return 1+la*rho
        if x==1 and y==1:return 1-rho
        return 1.
    def _make_features(self,d,fit=False):
        f=pd.DataFrame(index=d.index)
        f['xg_form_diff']=(d.home_xg_for_form-d.home_xg_against_form)-(d.away_xg_for_form-d.away_xg_against_form)
        f['shots_form_diff']=(d.home_shots_for_form-d.home_shots_against_form)-(d.away_shots_for_form-d.away_shots_against_form)
        f['sot_form_diff']=(d.home_sot_for_form-d.home_sot_against_form)-(d.away_sot_for_form-d.away_sot_against_form)
        if fit:
            for c in self.FEATURE_NAMES:
                self.feature_mean[c]=float(f[c].mean(skipna=True)) if f[c].notna().any() else 0.
                sd=float(f[c].std(skipna=True)) if f[c].notna().sum()>1 else 1.; self.feature_std[c]=sd if sd>1e-8 else 1.
        for c in self.FEATURE_NAMES:
            f[c]=((f[c]-self.feature_mean.get(c,0))/self.feature_std.get(c,1)).fillna(0).clip(-self.cfg.feature_clip,self.cfg.feature_clip)
            f[c+'_missing']=(d[c.replace('_form_diff','').replace('xg','home_xg')].isna().astype(float) if False else 0.)
        return f[self.FEATURE_NAMES].to_numpy(float)
    def _unpack(self,x):
        n=len(self.teams); k=len(self.FEATURE_NAMES) if self.use_advanced else 0
        att=x[:n]; de=x[n:2*n]; b0=x[2*n]; ha=x[2*n+1]; rho=np.clip(x[2*n+2],-.25,.25); beta=x[2*n+3:2*n+3+k]
        return att-att.mean(),de-de.mean(),b0,ha,rho,beta
    def fit(self,df,as_of=None):
        d=df[df.date>=pd.Timestamp(self.cfg.start_date)].copy()
        if as_of is not None:d=d[d.date<pd.Timestamp(as_of)]
        if len(d)<50:raise ValueError('Not enough historical matches')
        self.teams=sorted(set(d.home_team)|set(d.away_team)); self.tidx={t:i for i,t in enumerate(self.teams)}
        hi=d.home_team.map(self.tidx).to_numpy(); ai=d.away_team.map(self.tidx).to_numpy(); hg=d.home_score.to_numpy(); ag=d.away_score.to_numpy(); neutral=d.neutral.astype(float).to_numpy(); w=self._decay(d.date,d.date.max())
        adv_rows=d[['home_xg_for_form','away_xg_for_form','home_shots_for_form','away_shots_for_form','home_sot_for_form','away_sot_for_form']].notna().all(axis=1).sum()
        self.use_advanced=adv_rows>=self.cfg.min_advanced_matches
        X=self._make_features(d,fit=True) if self.use_advanced else np.zeros((len(d),0))
        n=len(self.teams); k=X.shape[1]; x0=np.zeros(2*n+3+k); x0[2*n]=math.log(max((hg.sum()+ag.sum())/(2*len(d)),.2)); x0[2*n+1]=self.cfg.home_adv
        def obj(x):
            att,de,b0,ha,rho,beta=self._unpack(x); adv=X@beta if k else 0
            lh=np.exp(np.clip(b0+att[hi]-de[ai]+ha*(1-neutral)+adv,-3,3)); la=np.exp(np.clip(b0+att[ai]-de[hi]-adv,-3,3))
            ll=poisson.logpmf(hg,lh)+poisson.logpmf(ag,la); tau=np.array([self._tau(int(a),int(b),float(c),float(e),rho) for a,b,c,e in zip(hg,ag,lh,la)]); ll+=np.log(np.clip(tau,1e-9,None))
            return -(w*ll).sum()+self.cfg.l2*(np.sum(att**2)+np.sum(de**2)+np.sum(beta**2))
        res=minimize(obj,x0,method='L-BFGS-B',options={'maxiter':700}); self.params=res.x
        att,de,b0,ha,self.rho,beta=self._unpack(res.x); sa=np.std(att) or 1; sd=np.std(de) or 1
        self.ratings={}
        for t,i in self.tidx.items():
            A=100/(1+np.exp(-att[i]/sa)); D=100/(1+np.exp(-de[i]/sd)); self.ratings[t]={'attack_raw':float(att[i]),'defense_raw':float(de[i]),'attack':round(float(A),1),'defense':round(float(D),1),'overall':round(float((A+D)/2),1)}
        self.fit_info={'success':bool(res.success),'matches':len(d),'advanced_rows':int(adv_rows),'advanced_enabled':self.use_advanced,'rho':float(self.rho),'feature_coefficients':dict(zip(self.FEATURE_NAMES,map(float,beta)))}
        return self
    def _feature_vector(self,features):
        if not self.use_advanced:return np.zeros(0)
        return np.array([np.clip((float(features.get(c,np.nan))-self.feature_mean[c])/self.feature_std[c],-self.cfg.feature_clip,self.cfg.feature_clip) if pd.notna(features.get(c,np.nan)) else 0 for c in self.FEATURE_NAMES])
    def lambdas(self,home,away,neutral=False,features=None):
        att,de,b0,ha,rho,beta=self._unpack(self.params); h=self.tidx[home]; a=self.tidx[away]; adv=float(self._feature_vector(features or {})@beta) if len(beta) else 0
        return float(np.exp(b0+att[h]-de[a]+ha*(not neutral)+adv)),float(np.exp(b0+att[a]-de[h]-adv))
    def score_matrix(self,home,away,neutral=False,features=None):
        lh,la=self.lambdas(home,away,neutral,features); g=np.arange(self.cfg.max_goals+1); M=np.outer(poisson.pmf(g,lh),poisson.pmf(g,la))
        for x in (0,1):
            for y in (0,1):M[x,y]*=self._tau(x,y,lh,la,self.rho)
        return lh,la,M/M.sum()
    def predict(self,home,away,neutral=False,features=None):
        lh,la,M=self.score_matrix(home,away,neutral,features); n=M.shape[0]; total=np.add.outer(np.arange(n),np.arange(n)); i,j=np.unravel_index(np.argmax(M),M.shape)
        out={'home':home,'away':away,'lambda_home':lh,'lambda_away':la,'home_win':float(np.tril(M,-1).sum()),'draw':float(np.trace(M)),'away_win':float(np.triu(M,1).sum()),'btts_yes':float(M[1:,1:].sum()),'most_likely_score':f'{i}-{j}','score_probability':float(M[i,j]),'rho':self.rho,'advanced_enabled':self.use_advanced,'home_ratings':self.ratings[home],'away_ratings':self.ratings[away]}
        out.update({f'over_{x:.1f}':float(M[total>x].sum()) for x in [.5,1.5,2.5,3.5,4.5,5.5]}); out['score_matrix']=M; return out
    def walk_forward(self,df,test_start='2022-01-01',refit_every=40):
        d=df.sort_values('date').reset_index(drop=True); rows=[]
        for k,(idx,r) in enumerate(d[d.date>=pd.Timestamp(test_start)].iterrows()):
            if k%refit_every==0:self.fit(d[d.date<r.date])
            if r.home_team not in self.tidx or r.away_team not in self.tidx:continue
            p=self.predict(r.home_team,r.away_team,bool(r.neutral)); probs=np.array([p['home_win'],p['draw'],p['away_win']]); outcome=0 if r.home_score>r.away_score else 1 if r.home_score==r.away_score else 2; one=np.eye(3)[outcome]
            rows.append({'date':r.date,'home':r.home_team,'away':r.away_team,'hg':r.home_score,'ag':r.away_score,'p_home':probs[0],'p_draw':probs[1],'p_away':probs[2],'log_loss':-math.log(max(probs[outcome],1e-12)),'brier':float(np.mean((probs-one)**2)),'advanced_enabled':p['advanced_enabled']})
        return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data',default=RESULTS_URL); ap.add_argument('--advanced',action='append',default=[]); ap.add_argument('--home'); ap.add_argument('--away'); ap.add_argument('--neutral',action='store_true'); ap.add_argument('--backtest',action='store_true'); ap.add_argument('--coverage',action='store_true')
    a=ap.parse_args(); d=DataPipeline.load_results(a.data); adv=DataPipeline.load_advanced(a.advanced); d=DataPipeline.merge(d,adv); d=DataPipeline.add_prematch_form(d)
    if a.coverage: print(DataPipeline.coverage(d).to_string(index=False))
    m=UEFAForecastModel().fit(d); print(json.dumps(m.fit_info,indent=2))
    if a.backtest:
        bt=m.walk_forward(d); bt.to_csv('backtest_predictions_v2.csv',index=False); print(bt[['log_loss','brier']].mean().to_string())
    if a.home and a.away:
        p=m.predict(a.home,a.away,a.neutral); M=p.pop('score_matrix'); print(pd.Series(p).to_string()); print(pd.DataFrame(M).round(4))
if __name__=='__main__':main()


import math, numpy as np, pandas as pd

def competition_weight(name):
    s=(name or "").lower()
    if "world cup" in s and ("qualification" not in s and "qualif" not in s): return 1.20
    if any(x in s for x in ["euro","copa américa","copa america","african cup","asian cup","gold cup","ofc nations"]): return 1.15
    if any(x in s for x in ["qualification","qualifier","qualif"]): return 1.08
    if "nations league" in s: return 1.02
    if "friendly" in s: return 0.65
    return 0.90

def team_recent_signal(matches, team, as_of=None, n=8):
    d=matches.copy()
    d["date"]=pd.to_datetime(d["date"])
    if as_of is not None:d=d[d["date"]<pd.Timestamp(as_of)]
    d=d[(d.home_team==team)|(d.away_team==team)].sort_values("date").tail(n)
    if d.empty:return {"n":0,"ppg":None,"gfpg":None,"gapg":None,"trend":0.0}
    pts=[];gf=[];ga=[]
    for _,r in d.iterrows():
        home=r.home_team==team
        a=int(r.home_score if home else r.away_score); b=int(r.away_score if home else r.home_score)
        gf.append(a);ga.append(b);pts.append(3 if a>b else 1 if a==b else 0)
    # newest gets more weight
    w=np.linspace(.55,1.0,len(d))
    return {"n":len(d),"ppg":float(np.average(pts,weights=w)),
            "gfpg":float(np.average(gf,weights=w)),"gapg":float(np.average(ga,weights=w)),
            "trend":float(np.clip((np.average(pts,weights=w)/3-.5)*2,-1,1))}

def uncertainty(matches, team, as_of=None):
    d=matches.copy();d["date"]=pd.to_datetime(d["date"])
    if as_of is not None:d=d[d["date"]<pd.Timestamp(as_of)]
    d=d[(d.home_team==team)|(d.away_team==team)].sort_values("date").tail(30)
    n=len(d)
    # interpretable evidence uncertainty, not a formal Bayesian posterior
    return {"recent_matches":n,"rating_uncertainty":round(max(2.5,12/math.sqrt(max(n,1))),2)}

def data_confidence(matches, h, a, advanced_rows=0, lineup_conf=0.0, as_of=None):
    uh=uncertainty(matches,h,as_of)["recent_matches"];ua=uncertainty(matches,a,as_of)["recent_matches"]
    history=min(1,(uh+ua)/40)
    adv=min(1,advanced_rows/10)
    score=100*(.72*history+.18*adv+.10*max(0,min(1,lineup_conf)))
    return int(round(score))

def explanation(pred, recent_h, recent_a, confidence):
    h,a=pred["home_team"],pred["away_team"];r=pred["ratings"];eg=pred["expected_goals"]
    p=pred["probabilities"];gap=r[h]["OVR"]-r[a]["OVR"]; xgap=eg[h]-eg[a]
    bits=[]
    if abs(gap)>=6:
        bits.append(f"{h if gap>0 else a} has the clearer underlying ATT/DEF strength advantage.")
    elif abs(gap)>=2:
        bits.append(f"{h if gap>0 else a} has a modest underlying rating edge, but the teams are not far apart.")
    else: bits.append("The underlying team-strength estimates are close, so the forecast remains relatively uncertain.")
    if abs(xgap)>=.30:
        bits.append(f"The matchup projects {h if xgap>0 else a} to create more scoring output ({eg[h]:.2f} vs {eg[a]:.2f} goals).")
    else: bits.append(f"Projected scoring rates are close ({eg[h]:.2f} vs {eg[a]:.2f}), increasing draw/upset probability.")
    if recent_h["n"] and recent_a["n"]:
        better=h if recent_h["ppg"]>recent_a["ppg"] else a
        bits.append(f"Recent results slightly favor {better} after recency weighting, while older matches still stabilize the ratings.")
    bits.append(f"Data-confidence score: {confidence}/100; this measures evidence coverage, not the chance the pick is correct.")
    return " ".join(bits)

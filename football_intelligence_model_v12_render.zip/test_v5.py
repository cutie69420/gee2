import numpy as np
from global_model_v5 import _dc_tau
# Dixon-Coles factors must remain positive in plausible range
for x in range(2):
  for y in range(2):
    assert _dc_tau(x,y,1.5,1.1,.05)>0
print("core probability correction tests passed")

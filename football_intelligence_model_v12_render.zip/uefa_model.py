from __future__ import annotations
import argparse, math, pathlib
from dataclasses import dataclass
from typing import Optional
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.stats import poisson

RESULTS_URL='https://raw.githubusercontent.com/martj42/international_results/master/results.csv'

@dataclass
class Config:
    start_date: str='2018-01-01'
    half_life_days: float=540.0
    rating_k: float=0.075
    home_adv: float=0.12
    max_goals: int=10
    l2: float=0.025

class UEFAForecastModel:
    def __init__(self,cfg=Config()):
        self.cfg=cfg; self.teams=[]; self.tidx={}; self.params=None; self.rho=0.0; self.ratings={}

    @staticmethod
    def load_results(path_or_url=RESULTS_URL):
        d=pd.read_csv(path_or_url, parse_dates=['date'])
        d=d.dropna(subset=['home_team','away_team','home_score','away_score']).copy()
        d[['home_score','away_score']]=d[['home_score','away_score']].astype(int)
        if 'neutral' not in d: d['neutral']=False
        d['neutral']=d['neutral'].astype(str).str.lower().map({'true':True,'false':False}).fillna(d['neutral']).astype(bool)
        return d.sort_values('date').reset_index(drop=True)

    @staticmethod
    def merge_advanced(results, advanced_path=None):
        # Expected columns: date,home_team,away_team,home_xg,away_xg,home_shots,away_shots,home_sot,away_sot
        cols=['home_xg','away_xg','home_shots','away_shots','home_sot','away_sot']
        if advanced_path is None:
            for c in cols: results[c]=np.nan
            return results
        a=pd.read_csv(advanced_path,parse_dates=['date'])
        key=['date','home_team','away_team']
        out=results.merge(a[key+[c for c in cols if c in a]],on=key,how='left')
        for c in cols:
            if c not in out: out[c]=np.nan
        return out

    def _decay(self, dates, ref):
        age=(ref-dates).dt.days.clip(lower=0).to_numpy()
        return np.exp(-math.log(2)*age/self.cfg.half_life_days)

    def _unpack(self,x):
        n=len(self.teams); att=x[:n]; deff=x[n:2*n]; intercept=x[-3]; home=x[-2]; rho=x[-1]
        # identifiability: centered team effects
        return att-att.mean(), deff-deff.mean(), intercept, home, np.clip(rho,-0.25,0.25)

    @staticmethod
    def _tau(x,y,lh,la,rho):
        if x==0 and y==0: return 1-lh*la*rho
        if x==0 and y==1: return 1+lh*rho
        if x==1 and y==0: return 1+la*rho
        if x==1 and y==1: return 1-rho
        return 1.0

    def fit(self,df,as_of=None):
        d=df[df.date>=pd.Timestamp(self.cfg.start_date)].copy()
        if as_of is not None: d=d[d.date<pd.Timestamp(as_of)]
        if len(d)<50: raise ValueError('Not enough historical matches to fit model.')
        self.teams=sorted(set(d.home_team)|set(d.away_team)); self.tidx={t:i for i,t in enumerate(self.teams)}
        hi=d.home_team.map(self.tidx).to_numpy(); ai=d.away_team.map(self.tidx).to_numpy()
        hg=d.home_score.to_numpy(); ag=d.away_score.to_numpy(); neutral=d.neutral.astype(float).to_numpy()
        ref=d.date.max(); w=self._decay(d.date,ref)
        n=len(self.teams); x0=np.zeros(2*n+3); x0[-3]=math.log(max((hg.sum()+ag.sum())/(2*len(d)),.2)); x0[-2]=self.cfg.home_adv
        def obj(x):
            att,deff,b0,ha,rho=self._unpack(x)
            lh=np.exp(np.clip(b0+att[hi]-deff[ai]+ha*(1-neutral),-3,3))
            la=np.exp(np.clip(b0+att[ai]-deff[hi],-3,3))
            ll=poisson.logpmf(hg,lh)+poisson.logpmf(ag,la)
            tau=np.array([self._tau(int(a),int(b),float(c),float(e),rho) for a,b,c,e in zip(hg,ag,lh,la)])
            ll+=np.log(np.clip(tau,1e-9,None))
            penalty=self.cfg.l2*(np.sum(att**2)+np.sum(deff**2))
            return -(w*ll).sum()+penalty
        res=minimize(obj,x0,method='L-BFGS-B',options={'maxiter':500})
        if not res.success: print('Optimizer warning:',res.message)
        self.params=res.x; att,deff,b0,ha,self.rho=self._unpack(res.x)
        self.ratings={t:{'attack_raw':att[i],'defense_raw':deff[i]} for t,i in self.tidx.items()}
        # 0-100 percentile-like logistic display ratings; higher defense means stronger defense
        sa=np.std(att) or 1; sd=np.std(deff) or 1
        for t in self.teams:
            a=self.ratings[t]['attack_raw']; de=self.ratings[t]['defense_raw']
            A=100/(1+np.exp(-a/sa)); D=100/(1+np.exp(-de/sd)); O=.5*(A+D)
            self.ratings[t].update(attack=round(float(A),1),defense=round(float(D),1),overall=round(float(O),1))
        return self

    def lambdas(self,home,away,neutral=False,features=None):
        if self.params is None: raise RuntimeError('Fit model first')
        if home not in self.tidx or away not in self.tidx: raise KeyError('Unknown team')
        att,deff,b0,ha,_=self._unpack(self.params); h=self.tidx[home]; a=self.tidx[away]
        lh=np.exp(b0+att[h]-deff[a]+ha*(not neutral)); la=np.exp(b0+att[a]-deff[h])
        # Optional verified advanced-stat residual adjustment, deliberately conservative.
        if features:
            dxg=float(features.get('xg_diff_form',0) or 0); dsot=float(features.get('sot_diff_form',0) or 0)
            adj=np.clip(.10*dxg+.015*dsot,-.30,.30); lh*=np.exp(adj); la*=np.exp(-adj)
        return float(lh),float(la)

    def score_matrix(self,home,away,neutral=False,features=None):
        lh,la=self.lambdas(home,away,neutral,features); g=np.arange(self.cfg.max_goals+1)
        M=np.outer(poisson.pmf(g,lh),poisson.pmf(g,la))
        for x in (0,1):
            for y in (0,1): M[x,y]*=self._tau(x,y,lh,la,self.rho)
        M=M/M.sum(); return lh,la,M

    def predict(self,home,away,neutral=False,features=None):
        lh,la,M=self.score_matrix(home,away,neutral,features); n=M.shape[0]
        hw=float(np.tril(M,-1).sum()); dr=float(np.trace(M)); aw=float(np.triu(M,1).sum())
        btts=float(M[1:,1:].sum()); total=np.add.outer(np.arange(n),np.arange(n))
        totals={f'over_{x:.1f}':float(M[total>x].sum()) for x in [0.5,1.5,2.5,3.5,4.5,5.5]}
        i,j=np.unravel_index(np.argmax(M),M.shape)
        return {'home':home,'away':away,'lambda_home':lh,'lambda_away':la,'home_win':hw,'draw':dr,'away_win':aw,
                'btts_yes':btts,**totals,'most_likely_score':f'{i}-{j}','score_probability':float(M[i,j]),
                'home_ratings':self.ratings[home],'away_ratings':self.ratings[away],'rho':self.rho,'score_matrix':M}

    def walk_forward(self,df,test_start='2022-01-01',refit_every=30):
        d=df.sort_values('date').reset_index(drop=True); tests=d[d.date>=pd.Timestamp(test_start)]
        rows=[]; fitted_until=None
        for k,(idx,r) in enumerate(tests.iterrows()):
            if k%refit_every==0 or fitted_until is None:
                self.fit(d[d.date<r.date]); fitted_until=r.date
            if r.home_team not in self.tidx or r.away_team not in self.tidx: continue
            p=self.predict(r.home_team,r.away_team,bool(r.neutral)); outcome=0 if r.home_score>r.away_score else 1 if r.home_score==r.away_score else 2
            probs=np.array([p['home_win'],p['draw'],p['away_win']]); one=np.eye(3)[outcome]
            rows.append({'date':r.date,'home':r.home_team,'away':r.away_team,'hg':r.home_score,'ag':r.away_score,
                         'p_home':probs[0],'p_draw':probs[1],'p_away':probs[2],
                         'log_loss':-math.log(max(probs[outcome],1e-12)),'brier':float(np.mean((probs-one)**2))})
        return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data',default=RESULTS_URL); ap.add_argument('--advanced'); ap.add_argument('--home'); ap.add_argument('--away'); ap.add_argument('--neutral',action='store_true'); ap.add_argument('--backtest',action='store_true')
    a=ap.parse_args(); d=UEFAForecastModel.load_results(a.data); d=UEFAForecastModel.merge_advanced(d,a.advanced)
    # Five-season/cycle-era history from 2018 onward; all senior internationals provide opponent context.
    m=UEFAForecastModel().fit(d)
    if a.backtest:
        bt=m.walk_forward(d); print(bt[['log_loss','brier']].mean()); bt.to_csv('backtest_predictions.csv',index=False)
    if a.home and a.away:
        p=m.predict(a.home,a.away,a.neutral); M=p.pop('score_matrix'); print(pd.Series(p).to_string()); print('\nScore grid:\n',pd.DataFrame(M).round(4))
if __name__=='__main__': main()

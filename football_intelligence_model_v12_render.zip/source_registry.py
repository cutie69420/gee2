SOURCES = {
 "core_results": {
   "name":"International Results Dataset",
   "priority":3,
   "kind":"public historical backbone",
   "fields":["date","teams","score","competition","city","country","neutral"],
   "url":"https://github.com/martj42/international_results"
 },
 "uefa": {
   "name":"UEFA",
   "priority":1,
   "kind":"official competition source",
   "fields":["fixtures","results","team stats","player stats","squads"],
   "url":"https://www.uefa.com/uefanationsleague/"
 },
 "fifa": {
   "name":"FIFA",
   "priority":1,
   "kind":"official governing-body source",
   "fields":["rankings","fixtures/results","member associations"],
   "url":"https://www.fifa.com/"
 },
 "sportmonks": {
   "name":"Sportmonks",
   "priority":2,
   "kind":"licensed structured provider",
   "fields":["fixtures","events","statistics","lineups","formations","sidelined","xG","xGOT","xPTS","npxG","xGA","player xG"],
   "url":"https://www.sportmonks.com/football-api/"
 }
}

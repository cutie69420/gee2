#!/bin/bash
cd "$(dirname "$0")"
python3 -m pip install -r requirements_v9.txt
[ -f data/international_results.csv ] || python3 data_fetch.py
python3 -m streamlit run app_v9.py

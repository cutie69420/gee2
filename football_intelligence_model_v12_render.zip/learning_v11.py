
import pandas as pd, numpy as np
from database import connect, settle_prediction

def auto_settle(results_csv="data/international_results.csv"):
    r=pd.read_csv(results_csv);r["date"]=pd.to_datetime(r["date"]).dt.date.astype(str)
    c=connect()
    q=pd.read_sql_query("SELECT id,match_date,home_team,away_team FROM predictions WHERE settled=0",c)
    done=0
    for _,p in q.iterrows():
        hit=r[(r.date==str(p.match_date))&(r.home_team==p.home_team)&(r.away_team==p.away_team)]
        if len(hit)==1:
            x=hit.iloc[0]; settle_prediction(int(p.id),int(x.home_score),int(x.away_score));done+=1
    c.close();return done

def calibration_bins():
    c=connect()
    d=pd.read_sql_query("SELECT p_home,p_draw,p_away,actual_home,actual_away FROM predictions WHERE settled=1",c);c.close()
    rows=[]
    for _,x in d.iterrows():
        probs=[x.p_home,x.p_draw,x.p_away];actual=0 if x.actual_home>x.actual_away else 1 if x.actual_home==x.actual_away else 2
        for i,p in enumerate(probs): rows.append((p,1 if i==actual else 0))
    if not rows:return pd.DataFrame(columns=["bin","n","mean_probability","observed_frequency"])
    z=pd.DataFrame(rows,columns=["p","y"]);z["bin"]=pd.cut(z.p,bins=np.linspace(0,1,11),include_lowest=True)
    return z.groupby("bin",observed=True).agg(n=("y","size"),mean_probability=("p","mean"),observed_frequency=("y","mean")).reset_index()

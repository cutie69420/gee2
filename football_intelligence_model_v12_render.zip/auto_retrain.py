from trainer_v9 import refresh_and_train
if __name__=="__main__":
    m=refresh_and_train()
    print("Updated through",m.as_of.date(),"using",len(m._train),"rolling-window matches.")

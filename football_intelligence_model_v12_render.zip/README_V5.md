
# Global Football Model v5

## One-command first run
Requires Python 3.10+:
```
pip install pandas numpy scipy
python predict_v5.py "Wales" "Norway" --refresh
```
`--refresh` downloads the maintained international-results CSV and stores it at
`data/international_results.csv`. Subsequent predictions work from the local copy.

## Historical design
Training uses only the five years before `--as-of`, with an exponential half-life
of 1.35 years, so roughly the latest two years dominate while older evidence
stabilizes ratings. Friendlies are downweighted.

## Prediction design
Opponent-adjusted attack/defense are fitted jointly by weighted Poisson likelihood.
Home advantage is learned from non-neutral internationals. Dixon-Coles rho is fitted
with the team parameters and corrects low-score dependence.

Lineup effects are optional and capped to +/-0.08 log-goals (~8%) per team. They are
match-day modifiers only and never overwrite historical team strength.

Every CLI forecast is appended to `prediction_ledger.jsonl` before the result is
known. This provides the basis for honest post-match scoring/calibration.

## Data integrity
The model refuses to train without real match data. Missing xG/shots/SOT are not
invented. Those advanced statistics remain an enrichment layer rather than a
requirement for global coverage.

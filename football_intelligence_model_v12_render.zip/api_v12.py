from __future__ import annotations
import os, threading
from datetime import date
from difflib import get_close_matches
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field

from paths_v12 import RESULTS_CSV, DB_PATH
from data_fetch import ensure_results
from trainer_v9 import train, MODEL_VERSION
from database import connect, save_prediction
from analytics_v11 import team_recent_signal, uncertainty, data_confidence, explanation

app = FastAPI(
    title="Football Intelligence Model",
    version="12.0",
    description="International national-team probabilistic forecasting API."
)

_lock = threading.RLock()
_model = None

class PredictionRequest(BaseModel):
    home_team: str
    away_team: str
    neutral: bool = False
    match_date: date | None = None
    lineup_home: float = Field(default=0.0, ge=-0.08, le=0.08)
    lineup_away: float = Field(default=0.0, ge=-0.08, le=0.08)

def model():
    global _model
    with _lock:
        if _model is None:
            ensure_results(str(RESULTS_CSV), refresh=False)
            _model = train(str(RESULTS_CSV))
        return _model

def resolve(q: str, teams: list[str]) -> str:
    q=(q or "").strip()
    aliases={"usa":"United States","us":"United States",
             "cote d'ivoire":"Ivory Coast","ivory coast":"Ivory Coast"}
    exact={t.lower():t for t in teams}
    if q.lower() in aliases and aliases[q.lower()] in teams:
        return aliases[q.lower()]
    if q.lower() in exact:
        return exact[q.lower()]
    starts=[t for t in teams if t.lower().startswith(q.lower())]
    if len(starts)==1:
        return starts[0]
    close=get_close_matches(q,teams,n=5,cutoff=.55)
    raise HTTPException(422, detail={"message":"Team not recognized uniquely","suggestions":close})

@app.on_event("startup")
def startup():
    connect()

@app.get("/")
def root():
    return {
        "service":"Football Intelligence Model",
        "version":MODEL_VERSION,
        "docs":"/docs",
        "health":"/health",
        "predict":"POST /predict"
    }

@app.get("/health")
def health():
    m=model()
    return {
        "ok":True,
        "model_version":MODEL_VERSION,
        "trained_through":str(m.as_of.date()),
        "teams":len(m.teams),
        "training_matches":len(m._train),
        "database":str(DB_PATH)
    }

@app.get("/teams")
def teams():
    return {"teams":model().teams}

@app.post("/predict")
def predict(req: PredictionRequest):
    m=model()
    h=resolve(req.home_team,m.teams); a=resolve(req.away_team,m.teams)
    if h==a:
        raise HTTPException(422,detail="Choose two different teams.")
    pred=m.predict(h,a,req.neutral,req.lineup_home,req.lineup_away)
    rh=team_recent_signal(m.matches,h,m.as_of)
    ra=team_recent_signal(m.matches,a,m.as_of)
    conf=data_confidence(m.matches,h,a,advanced_rows=0,lineup_conf=0.0,as_of=m.as_of)
    pred["recent_form"]={h:rh,a:ra}
    pred["uncertainty"]={h:uncertainty(m.matches,h,m.as_of),a:uncertainty(m.matches,a,m.as_of)}
    pred["data_confidence"]=conf
    pred["explanation"]=explanation(pred,rh,ra,conf)
    pred["model_version"]=MODEL_VERSION
    save_prediction(pred, str(req.match_date) if req.match_date else None,
                    "neutral" if req.neutral else "home", MODEL_VERSION)
    return pred

@app.post("/admin/retrain")
def retrain(authorization: str | None = Header(default=None)):
    global _model
    secret=os.getenv("FOOTBALL_ADMIN_KEY","")
    if not secret:
        raise HTTPException(503,detail="FOOTBALL_ADMIN_KEY is not configured.")
    if authorization != f"Bearer {secret}":
        raise HTTPException(401,detail="Unauthorized.")
    with _lock:
        ensure_results(str(RESULTS_CSV),refresh=True)
        _model=train(str(RESULTS_CSV))
        return {
            "ok":True,
            "model_version":MODEL_VERSION,
            "trained_through":str(_model.as_of.date()),
            "teams":len(_model.teams),
            "training_matches":len(_model._train)
        }

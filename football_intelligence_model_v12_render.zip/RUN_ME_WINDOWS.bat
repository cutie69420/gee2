@echo off
cd /d %~dp0
python -m pip install -r requirements_v9.txt
if not exist data\international_results.csv python data_fetch.py
python -m streamlit run app_v9.py
pause

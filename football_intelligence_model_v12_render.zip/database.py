import sqlite3, json, hashlib
from pathlib import Path
import pandas as pd
from paths_v12 import DB_PATH
DB=str(DB_PATH)
SCHEMA="""
CREATE TABLE IF NOT EXISTS predictions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 match_date TEXT, home_team TEXT, away_team TEXT, venue TEXT,
 p_home REAL,p_draw REAL,p_away REAL,lambda_home REAL,lambda_away REAL,
 score_home INTEGER,score_away INTEGER,model_version TEXT,payload TEXT,
 settled INTEGER DEFAULT 0,actual_home INTEGER,actual_away INTEGER,
 log_loss REAL,brier REAL,rps REAL);
CREATE TABLE IF NOT EXISTS advanced_stats(
 id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,home_team TEXT,away_team TEXT,
 xg_home REAL,xg_away REAL,shots_home REAL,shots_away REAL,sot_home REAL,sot_away REAL,
 possession_home REAL,possession_away REAL,big_chances_home REAL,big_chances_away REAL,
 source TEXT,fixture_id TEXT, UNIQUE(date,home_team,away_team,source));
CREATE TABLE IF NOT EXISTS lineup_snapshots(
 id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 match_date TEXT,team TEXT,opponent TEXT,status TEXT,formation TEXT,
 players_json TEXT,absences_json TEXT,source TEXT,confidence REAL);
CREATE TABLE IF NOT EXISTS source_observations(
 id INTEGER PRIMARY KEY AUTOINCREMENT,observed_at TEXT DEFAULT CURRENT_TIMESTAMP,
 match_date TEXT,home_team TEXT,away_team TEXT,field TEXT,value TEXT,
 source_name TEXT,source_url TEXT,source_priority INTEGER,verified INTEGER DEFAULT 0,
 UNIQUE(match_date,home_team,away_team,field,source_name));
CREATE TABLE IF NOT EXISTS model_runs(
 id INTEGER PRIMARY KEY AUTOINCREMENT,trained_at TEXT DEFAULT CURRENT_TIMESTAMP,
 version TEXT,as_of TEXT,n_matches INTEGER,n_teams INTEGER,history_years REAL,
 half_life REAL,notes TEXT);
"""
def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c=sqlite3.connect(DB); c.executescript(SCHEMA); c.commit(); return c
def save_prediction(p,match_date=None,venue="home",version="v9"):
    c=connect(); pr=p["probabilities"]; eg=p["expected_goals"]; sc=p["most_likely_score"]
    c.execute("""INSERT INTO predictions(match_date,home_team,away_team,venue,p_home,p_draw,p_away,
    lambda_home,lambda_away,score_home,score_away,model_version,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
    (match_date,p["home_team"],p["away_team"],venue,pr["home_win"],pr["draw"],pr["away_win"],
     eg[p["home_team"]],eg[p["away_team"]],sc["home"],sc["away"],version,json.dumps(p)))
    c.commit(); c.close()
def settle_prediction(pid,ah,aa):
    c=connect(); row=c.execute("SELECT p_home,p_draw,p_away FROM predictions WHERE id=?",(pid,)).fetchone()
    if not row: raise ValueError("Prediction not found")
    ph,pd,pa=row; actual=0 if ah>aa else 1 if ah==aa else 2; probs=[ph,pd,pa]
    import math
    ll=-math.log(max(probs[actual],1e-12))
    y=[1.0 if i==actual else 0.0 for i in range(3)]
    brier=sum((probs[i]-y[i])**2 for i in range(3))
    # ranked probability score for ordered H/D/A categories
    rps=((ph-y[0])**2 + ((ph+pd)-(y[0]+y[1]))**2)/2
    c.execute("""UPDATE predictions SET settled=1,actual_home=?,actual_away=?,log_loss=?,brier=?,rps=? WHERE id=?""",
              (ah,aa,ll,brier,rps,pid)); c.commit();c.close()
def table(name):
    allowed={"predictions","advanced_stats","lineup_snapshots","source_observations","model_runs"}
    if name not in allowed: raise ValueError("bad table")
    c=connect();d=pd.read_sql_query(f"SELECT * FROM {name} ORDER BY id DESC",c);c.close();return d
def record_run(version,as_of,n_matches,n_teams,history_years,half_life,notes=""):
    c=connect();c.execute("""INSERT INTO model_runs(version,as_of,n_matches,n_teams,history_years,half_life,notes)
    VALUES(?,?,?,?,?,?,?)""",(version,as_of,n_matches,n_teams,history_years,half_life,notes));c.commit();c.close()
